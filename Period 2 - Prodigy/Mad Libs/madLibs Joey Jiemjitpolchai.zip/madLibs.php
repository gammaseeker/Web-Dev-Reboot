<!DOCTYPE HTML>
<!-- Joey Jiemjitpolchai -->
<html> 
	<head> 
		<title> </title>
		<style>
			span
			{
				color: red;
			}
		</style>
		<script> </script>
	</head>
	<body>  
			
			
			Once upon a time, a <span><?php echo $_POST['adj']; ?></span> princess <span><?php echo $_POST['verb']; ?> </span>
			 a <span><?php echo $_POST['noun']; ?> <?php echo $_POST['adverb']; ?></span>. 
			And she <span><?php echo $_POST['pastV']; ?></span>  happily ever after.		
	</body>
	
</html>