<!DOCTYPE HTML>
<!-- Joey Jiemjitpolchai -->
<html> 
	<head> 
		<title> </title>
		<style> </style>
		<script> </script>
	</head>
	<body> 
		<form method = "post" action = "madLibs.php">
			Once upon a time, a <input type = "text" name = "adj"/> princess <input type = "text" name = "verb"/> 
			 a <input type = "text" name = "noun"/> <input type = "text" name = "adverb"/>. 
			And she <input type = "text" name = "pastV"/>  happily ever after.
			<input type = "submit"/>
		</form>
	</body>
	
</html>